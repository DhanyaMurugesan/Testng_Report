package TestNg_soapui.soapuiCase;

import org.testng.annotations.Test;
import org.testng.Assert;
import java.io.IOException;
import java.util.Iterator;
import org.apache.xmlbeans.XmlException;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.impl.wsdl.WsdlTestSuite;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
import com.eviware.soapui.model.support.PropertiesMap;
import com.eviware.soapui.model.testsuite.TestCase;
import com.eviware.soapui.model.testsuite.TestRunner;
import com.eviware.soapui.model.testsuite.TestRunner.Status;
import com.eviware.soapui.support.SoapUIException;

import com.aventstack.extentreports.testng.listener.ExtentIReporterSuiteListenerAdapter;


@Listeners(ExtentIReporterSuiteListenerAdapter.class)
public class AppTest{
	private static WsdlProject project;
	private static WsdlTestSuite testSuite;
	
   @BeforeSuite
   public void initialize() throws XmlException, IOException, SoapUIException {
	   project=new WsdlProject("E:\\REST-Project-2-soapui-project.xml");
	      testSuite=project.getTestSuiteByName("Verify GET Request");
	     
   }
   
   
   @DataProvider(name = "tests")
   public static Iterator<TestCase> data() {
	   System.out.println(testSuite.getTestCases().keySet());
	   return testSuite.getTestCaseList().iterator();
	   
   }

   // This test will run 4 times since we have 5 parameters defined
   @Test(dataProvider = "tests")
   public void test(WsdlTestCase testCase) {
	   System.out.println(testCase.getName());
	
      TestRunner runner=testCase.run(new PropertiesMap(), false);
      System.out.println(runner.getStatus());
      Assert.assertEquals(Status.FINISHED, runner.getStatus());
   }



}
