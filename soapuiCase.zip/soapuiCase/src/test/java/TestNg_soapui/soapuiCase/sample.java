package TestNg_soapui.soapuiCase;

import java.io.IOException;

import org.apache.xmlbeans.XmlException;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.impl.wsdl.WsdlTestSuite;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;

import com.eviware.soapui.model.support.PropertiesMap;
import com.eviware.soapui.model.testsuite.TestRunner;
import com.eviware.soapui.model.testsuite.TestRunner.Status;
import com.eviware.soapui.support.SoapUIException;


public class sample {
	static ExtentTest test;
	static ExtentReports report;
	@BeforeClass
	public static void startTest()
	{
	report = new ExtentReports("E:\\ExtentReportResults.html");
	test = report.startTest("ExtentDemo");
	}
    @Test
	public void SoapTest() throws XmlException, IOException, SoapUIException {
		// TODO Auto-generated method stub
 WsdlProject project=new WsdlProject("E:\\REST-Project-2-soapui-project.xml");
 WsdlTestSuite testSuite=project.getTestSuiteByName("Verify GET Request");
 for(int i=0;i<testSuite.getTestCaseCount();i++){
	 WsdlTestCase testCase=testSuite.getTestCaseAt(i);
	 TestRunner runner=testCase.run(new PropertiesMap(), false);
	 if(runner.getStatus().equals(Status.FINISHED))
	 {
	 test.log(LogStatus.PASS, testCase.getName() +" : Passed");
	 }
	 else
	 {
	 test.log(LogStatus.FAIL, testCase.getName() +" : Failed");
	 }
	
 }
 
	}
    @AfterClass
    public static void endTest()
    {
    report.endTest(test);
    report.flush();
    }
}